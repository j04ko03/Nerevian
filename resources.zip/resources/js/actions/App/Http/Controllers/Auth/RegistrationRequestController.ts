import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Auth\RegistrationRequestController::store
 * @see app/Http/Controllers/Auth/RegistrationRequestController.php:15
 * @route '/api/registration-requests'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/registration-requests',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Auth\RegistrationRequestController::store
 * @see app/Http/Controllers/Auth/RegistrationRequestController.php:15
 * @route '/api/registration-requests'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Auth\RegistrationRequestController::store
 * @see app/Http/Controllers/Auth/RegistrationRequestController.php:15
 * @route '/api/registration-requests'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Auth\RegistrationRequestController::store
 * @see app/Http/Controllers/Auth/RegistrationRequestController.php:15
 * @route '/api/registration-requests'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Auth\RegistrationRequestController::store
 * @see app/Http/Controllers/Auth/RegistrationRequestController.php:15
 * @route '/api/registration-requests'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
const RegistrationRequestController = { store }

export default RegistrationRequestController