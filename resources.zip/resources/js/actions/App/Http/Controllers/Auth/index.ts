import AuthController from './AuthController'
import RegistrationRequestController from './RegistrationRequestController'
import AdminPeticionsController from './AdminPeticionsController'
const Auth = {
    AuthController: Object.assign(AuthController, AuthController),
RegistrationRequestController: Object.assign(RegistrationRequestController, RegistrationRequestController),
AdminPeticionsController: Object.assign(AdminPeticionsController, AdminPeticionsController),
}

export default Auth