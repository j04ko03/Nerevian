import Auth from './Auth'
import General from './General'
const Controllers = {
    Auth: Object.assign(Auth, Auth),
General: Object.assign(General, General),
}

export default Controllers