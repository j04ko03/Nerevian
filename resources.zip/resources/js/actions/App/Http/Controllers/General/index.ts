import DashboardController from './DashboardController'
const General = {
    DashboardController: Object.assign(DashboardController, DashboardController),
}

export default General