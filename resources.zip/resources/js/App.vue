<template>
    <router-view />
</template>
