import { computed } from 'vue';
import {
    LayoutDashboard,
    Users,
    ClipboardList,
    Database,
    Settings,
    FileText,
    Package,
    Truck,
    Bell,
    Send,
    ShoppingBag,
    MapPin,
} from 'lucide-vue-next';

const navConfig = {
    admin: [
        { label: 'Dashboard', to: '/admin/dashboard', icon: LayoutDashboard },
        { label: 'Usuarios', to: '/admin/usuarios', icon: Users },
        {
            label: 'Peticiones Registro',
            to: '/admin/peticiones',
            icon: ClipboardList,
        },
        { label: 'Datos Maestros', to: '/admin/datos', icon: Database },
        { label: 'Configuración', to: '/admin/config', icon: Settings },
    ],
    operador: [
        {
            label: 'Dashboard',
            to: '/operador/dashboard',
            icon: LayoutDashboard,
        },
        {
            label: 'Peticiones de Oferta',
            to: '/operador/peticiones',
            icon: ClipboardList,
        },
        { label: 'Cotizaciones', to: '/operador/cotizaciones', icon: FileText },
        { label: 'Precontratos', to: '/operador/precontratos', icon: FileText },
        { label: 'Expediciones', to: '/operador/expediciones', icon: Truck },
        { label: 'Clientes', to: '/operador/clientes', icon: Users },
        { label: 'Documentos', to: '/operador/documentos', icon: Package },
        { label: 'Notificaciones', to: '/operador/notificaciones', icon: Bell },
    ],
    cliente: [
        { label: 'Dashboard', to: '/cliente/dashboard', icon: LayoutDashboard },
        {
            label: 'Solicitudes de Oferta',
            to: '/cliente/solicitudes',
            icon: Send,
        },
        { label: 'Mis Pedidos', to: '/cliente/pedidos', icon: ShoppingBag },
        { label: 'Tracking', to: '/cliente/tracking', icon: MapPin },
        { label: 'Documentos', to: '/cliente/documentos', icon: Package },
        { label: 'Notificaciones', to: '/cliente/notificaciones', icon: Bell },
    ],
};

export function useNavItems(role) {
    const items = computed(() => navConfig[role] ?? []);
    return { items };
}
