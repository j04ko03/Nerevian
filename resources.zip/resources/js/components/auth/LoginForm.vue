<template>
    <form @submit.prevent="handleSubmit" class="login-form">
        <div class="input-group">
            <label for="email" class="label">Correo Electrónico</label>
            <input
                type="email"
                id="email"
                v-model="form.email"
                placeholder="nombre@empresa.com"
                class="input-field"
                required
            />
        </div>

        <div class="input-group">
            <label for="password" class="label">Contraseña</label>
            <input
                type="password"
                id="password"
                v-model="form.password"
                placeholder="••••••••"
                class="input-field"
                required
            />
        </div>

        <div class="forgot-password">
            <a href="#">¿Olvidaste tu contraseña?</a>
        </div>

        <button type="submit" class="btn btn-primary">Iniciar Sesión</button>
    </form>
</template>

<script setup>
import { reactive } from 'vue';

const form = reactive({ email: '', password: '' });
const emit = defineEmits(['login']);

const handleSubmit = () => {
    emit('login', { email: form.email, password: form.password });
};
</script>

<style scoped>
/* Eliminamos el @import de Montserrat porque Instrument Sans ya se carga en tu HTML principal */

.login-form {
    display: flex;
    flex-direction: column;
}

.input-group {
    display: flex;
    flex-direction: column;
    margin-bottom: 1.25rem;
}

.label {
    font-family: 'Instrument Sans', system-ui, sans-serif;
    font-weight: 600; /* SemiBold para dar fuerza a la etiqueta */
    color: #160800;
    margin-bottom: 0.4rem;
    font-size: 0.85rem;
}

.input-field {
    font-family: 'Instrument Sans', system-ui, sans-serif;
    font-weight: 500; /* Medium para que el texto tecleado sea muy legible */
    padding: 0.85rem 1rem;
    border: 1.5px solid #e2e8f0;
    border-radius: 8px;
    font-size: 0.95rem;
    color: #333;
    outline: none;
    transition: all 0.2s ease-in-out;
}

.input-field::placeholder {
    color: #94a3b8;
    font-weight: 400; /* Regular para el placeholder */
}

/* Estado Focus: Borde turquesa y sombra sutil */
.input-field:focus {
    border-color: #118c8c;
    box-shadow: 0 0 0 3px rgba(17, 140, 140, 0.15);
}

.forgot-password {
    text-align: right;
    margin-top: -0.5rem;
    margin-bottom: 1.75rem;
}

.forgot-password a {
    font-family: 'Instrument Sans', system-ui, sans-serif;
    font-size: 0.85rem;
    color: #118c8c;
    text-decoration: none;
    font-weight: 500;
    transition: color 0.2s;
}

.forgot-password a:hover {
    color: #0a3a40;
    text-decoration: underline;
}

.btn {
    font-family: 'Instrument Sans', system-ui, sans-serif;
    font-weight: 600;
    width: 100%;
    padding: 0.85rem;
    border-radius: 8px;
    cursor: pointer;
    font-size: 1rem;
    transition: all 0.3s ease;
}

.btn-primary {
    background-color: #118c8c;
    color: #fffdee;
    border: none;
    box-shadow: 0 4px 6px rgba(17, 140, 140, 0.2);
}

.btn-primary:hover {
    background-color: #0a3a40;
    transform: translateY(-1px);
    box-shadow: 0 6px 8px rgba(10, 58, 64, 0.25);
}

.btn-primary:active {
    transform: translateY(0);
}
</style>
