<template>
    <div class="stats-grid">
        <StatCard
            label="Total Usuarios"
            :value="stats.totalUsuarios"
            badge="+12"
            compare="vs mes anterior"
        >
            <template #icon><Users :size="18" /></template>
        </StatCard>

        <StatCard
            label="Peticiones pendientes"
            :value="stats.peticionesPendientes"
        >
            <template #icon><UserPlus :size="18" /></template>
        </StatCard>

        <StatCard label="Total Operadores" :value="stats.totalOperadores">
            <template #icon><Monitor :size="18" /></template>
        </StatCard>
    </div>
</template>

<script setup>
import { Users, UserPlus, Monitor } from 'lucide-vue-next';
import StatCard from './StatCard.vue';

defineProps({
    stats: {
        type: Object,
        required: true,
    },
});
</script>

<style scoped>
.stats-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 1rem;
    margin-bottom: 1.5rem;
}
</style>
