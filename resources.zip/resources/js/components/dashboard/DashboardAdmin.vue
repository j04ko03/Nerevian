<template>
    <AppLayout>
        <div class="dashboard">
            <DashboardHeader />

            <div v-if="loading" class="loading-state">
                <div class="spinner" />
            </div>

            <template v-else>
                <StatsGrid :stats="stats" />

                <div class="bottom-grid">
                    <UltimosUsuarios :usuarios="ultimosUsuarios" />
                    <ActividadSistema :actividad="monitorCarga" />
                </div>
            </template>
        </div>
    </AppLayout>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import AppLayout from '@/layout/AppLayout.vue';
import api from '@/plugins/axios';

import DashboardHeader from '@/components/dashboard/components/DashboardHeader.vue';
import StatsGrid from '@/components/dashboard/components/StatsGrid.vue';
import UltimosUsuarios from '@/components/dashboard/components/UltimosUsuarios.vue';
import ActividadSistema from '@/components/dashboard/components/ActividadSistema.vue';

const loading = ref(true);
const stats = ref({
    totalUsuarios: 0,
    peticionesPendientes: 0,
    totalOperadores: 0,
});
const monitorCarga = ref([]);
const ultimosUsuarios = ref([]);

onMounted(async () => {
    try {
        const { data } = await api.get('/admin/dashboard');
        if (data.success) {
            stats.value = data.stats;
            monitorCarga.value = data.monitorCarga;
            ultimosUsuarios.value = data.ultimosUsuarios;
        }
    } finally {
        loading.value = false;
    }
});
</script>

<style scoped>
.dashboard {
    padding: 2rem 2.5rem;
    min-height: 100vh;
    background: #f5f7f0;
    font-family: 'Instrument Sans', system-ui, sans-serif;
}
.bottom-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 1rem;
}
.loading-state {
    display: flex;
    justify-content: center;
    padding: 4rem;
}
.spinner {
    width: 32px;
    height: 32px;
    border: 3px solid #e5e7eb;
    border-top-color: #1a8a7d;
    border-radius: 50%;
    animation: spin 0.7s linear infinite;
}
@keyframes spin {
    to {
        transform: rotate(360deg);
    }
}
</style>
