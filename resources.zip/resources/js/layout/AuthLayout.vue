<template>
    <div class="auth-wrapper">
        <div class="auth-container">
            <div class="logo-container">
                <img src="logo.svg" alt="Nerevian Logo" class="logo" />
            </div>

            <slot />
        </div>
    </div>
</template>

<style scoped>
.auth-wrapper {
    min-height: 100vh;
    background-color: #fffdee; /* Fondo crema general */
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 2rem 1rem;
}

.auth-container {
    width: 100%;
    max-width: 600px; /* Ancho suficiente para el form de registro a 2 columnas */
    display: flex;
    flex-direction: column;
}

.logo-container {
    display: flex;
    text-align: center;
    justify-content: center;
    margin-bottom: 2rem;
}

.logo {
    height: 60px; /* Ajusta la altura de tu logo real */
    object-fit: contain;
}
</style>
