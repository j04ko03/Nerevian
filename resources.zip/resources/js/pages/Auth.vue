<template>
    <AuthLayout>
        <!-- BACK LINK (only for register) -->
        <div v-if="view === 'register'" class="back-link-container">
            <router-link to="/login" class="back-link">&larr; Volver al login</router-link>
        </div>

        <main v-if="view === 'login' || view === 'register'" class="auth-card" :class="view + '-card'">
            <div class="page-header">
                <h2>{{ title }}</h2>
                <p>{{ subtitle }}</p>
            </div>

            <LoginForm v-if="view === 'login'" @login="procesarLogin" />
            <RegisterForm v-if="view === 'register'" @submitRegistro="enviarDatosLaravel" />
        </main>

        <div v-if="view === 'register-confirmed'" class="confirm-box">
            <div class="check-icon">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                    <polyline points="20 6 9 17 4 12"></polyline>
                </svg>
            </div>
            <h2 class="title">Solicitud Enviada</h2>
            <p class="message">
                Hemos recibido tu solicitud de registro. Un administrador
                revisará tus datos y te contactará en breve.
            </p>
            <RouterLink to="/login" class="btn-primary">Volver al Inicio</RouterLink>
        </div>

        <footer v-if="view === 'login'" class="auth-footer">
            <p>
                ¿No tienes cuenta?
                <router-link to="/register">Solicitar registro</router-link>
            </p>
        </footer>
    </AuthLayout>
</template>

<script setup>
import { computed } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import AuthLayout from '@/layout/AuthLayout.vue';
import LoginForm from '@/components/auth/LoginForm.vue';
import RegisterForm from '@/components/auth/RegisterForm.vue';
import { useAuthStore } from '@/stores/authStore';
import api from '@/plugins/axios';

const route = useRoute();
const router = useRouter();
const auth = useAuthStore();

// Dynamically determine the view state from the route name
const view = computed(() => route.name);

const title = computed(() => {
    return view.value === 'login' ? 'Bienvenido a Nerevian' : 'Solicitud de Registro';
});

const subtitle = computed(() => {
    return view.value === 'login' ? 'Plataforma integral de gestión logística' : 'Completa el formulario para unirte a Nerevian';
});

const procesarLogin = async (credenciales) => {
    try {
        await auth.login({
            correu: credenciales.email,
            contrasenya: credenciales.password,
        });
        router.push('/dashboard');
    } catch (error) {
        alert('Credenciales incorrectas');
    }
};

const enviarDatosLaravel = async (datos) => {
    try {
        console.log('Datos que van al servidor:', datos);
        await api.post('/registration-requests', datos);
        router.push('/register-confirmed');
    } catch (error) {
        alert('Error al enviar la solicitud.');
    }
};
</script>

<style scoped>
.page-header {
    text-align: center;
    margin-bottom: 2rem;
}
.page-header h2 {
    font-family: 'Instrument Sans', system-ui, sans-serif;
    font-weight: bold;
    letter-spacing: 1px;
    color: #160800;
    font-size: 1.5rem;
    margin-bottom: 0.5rem;
}
.page-header p {
    font-family: 'Instrument Sans', system-ui, sans-serif;
    color: #666;
    font-size: 1rem;
}
.auth-card {
    background-color: #fffdee;
    border-radius: 8px;
    padding: 2.5rem;
    margin-bottom: 1.5rem;
}
.login-card {
    border: 1.5px solid #118c8c;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
    max-width: 450px;
    margin-left: auto;
    margin-right: auto;
    width: 100%;
}
.register-card {
    border: 1.5px solid #118c8c;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
}
.auth-footer {
    text-align: center;
    font-family: 'Instrument Sans', system-ui, sans-serif;
    font-size: 0.95rem;
    color: #666;
}
.auth-footer a {
    color: #118c8c;
    font-weight: 500;
    text-decoration: none;
}
.back-link-container {
    margin-bottom: 1rem;
    width: 100%;
    text-align: left;
}
.back-link {
    font-family: 'Instrument Sans', system-ui, sans-serif;
    color: #666;
    text-decoration: none;
    font-size: 0.95rem;
}
.back-link:hover {
    color: #118c8c;
}

/* Confirmed Box Styles */
.confirm-box {
    display: flex;
    flex-direction: column;
    justify-content: center;
    text-align: center;
    background: white;
    border: 1px solid #e5e7eb;
    border-radius: 12px;
    padding: 3rem 2.5rem;
    width: 100%;
    max-width: 420px;
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03);
    font-family: 'Instrument Sans', system-ui, sans-serif;
    margin: 0 auto;
}
.check-icon {
    width: 64px;
    height: 64px;
    background: #d1fae5;
    color: #059669;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 1.5rem;
}
.confirm-box .title {
    font-size: 1.5rem;
    font-weight: 700;
    color: #111827;
    margin: 0 0 1rem;
}
.confirm-box .message {
    color: #6b7280;
    font-size: 0.95rem;
    line-height: 1.6;
    margin: 0 0 2rem;
}
.btn-primary {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    background: #1a8a7d;
    color: white;
    border-radius: 6px;
    padding: 0.75rem 2rem;
    font-size: 0.95rem;
    font-weight: 500;
    text-decoration: none;
    transition: background-color 0.2s;
    width: 100%;
    box-sizing: border-box;
}
.btn-primary:hover {
    background: #14706a;
}
</style>
